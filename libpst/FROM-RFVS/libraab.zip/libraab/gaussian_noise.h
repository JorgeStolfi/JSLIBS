double uniform(int* seed);
double BoxMuller(double mean, double sigma,int* seed);
double CLTM(int N, double mean, double sigma,int* seed);
