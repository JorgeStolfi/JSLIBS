#include <stdio.h>
#include <stdlib.h>
#include "vetorn.h"

vetorn* cria_vetorn(int tam){
	return cria_vetor(tam);
}
vetorn* cria_vetor(int tam){
	vetorn* novo;
	novo = (vetorn*)malloc(sizeof(vetorn));
	novo->tam = tam;
	novo->valor = (double*)malloc(sizeof(double)*tam);
	return novo;
}

void libera_vetor(vetorn* vet){
	free(vet->valor);
	free(vet);
}

double** AlocaMatriz(int m, int n){
	int i;
	double** novo = (double**)malloc(sizeof(double*)*m);
	for(i = 0; i < m;i++){
		novo[i] = (double*)malloc(sizeof(double)*n);
	}
	return novo;
}

void FreeMatriz(double** M, int m, int n){
	int i;
	for(i = 0; i < m;i++){
		free(M[i]);
	}
	free(M);
}
