#ifndef vetorn_H
#define vetorn_H

struct VetorN{
	int tam;
	double* valor;
};
typedef  struct VetorN vetorn;

vetorn* cria_vetorn(int tam);
vetorn* cria_vetor(int tam);
void libera_vetor(vetorn* vet);

double** AlocaMatriz(int m, int n);
void FreeMatriz(double** M, int m, int n);
#endif
